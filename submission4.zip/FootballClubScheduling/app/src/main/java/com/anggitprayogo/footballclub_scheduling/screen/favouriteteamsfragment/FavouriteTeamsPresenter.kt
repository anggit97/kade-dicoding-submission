package com.anggitprayogo.footballclub_scheduling.screen.favouriteteamsfragment

class FavouriteTeamsPresenter(){
}