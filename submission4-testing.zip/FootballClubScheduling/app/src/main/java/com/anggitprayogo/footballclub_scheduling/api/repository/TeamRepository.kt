package com.anggitprayogo.footballclub_scheduling.api.repository

import com.anggitprayogo.footballclub_scheduling.api.RetrofitService
import com.anggitprayogo.footballclub_scheduling.network.ApiClient
import retrofit2.Call
import retrofit2.Response

class TeamRepository {



}