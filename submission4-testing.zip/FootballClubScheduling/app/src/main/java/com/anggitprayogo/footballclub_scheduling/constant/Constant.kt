package com.anggitprayogo.footballclub_scheduling.constant

class Constant {

    companion object {
        val ID_EVENT: String = "ID_EVENT"
    }

}