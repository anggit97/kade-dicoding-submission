package com.anggitprayogo.footballclub_scheduling.screen.detail_schedule.model.detail_event

import com.google.gson.annotations.SerializedName

data class Response(

	@SerializedName("events")
	var events: List<EventsItem?>? = null
)