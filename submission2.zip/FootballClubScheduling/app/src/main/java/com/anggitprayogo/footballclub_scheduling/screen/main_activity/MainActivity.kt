package com.anggitprayogo.footballclub_scheduling.screen.main_activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.Fragment
import com.anggitprayogo.footballclub_scheduling.R
import com.anggitprayogo.footballclub_scheduling.screen.next_schedule_fragment.NextScheduleFragment
import com.anggitprayogo.footballclub_scheduling.screen.prev_schedule_fragment.PrevScheduleFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(){

    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        openFragment(PrevScheduleFragment())

        navigation_bottom.setOnNavigationItemSelectedListener(mNavigationBottomListener)
    }

    private val mNavigationBottomListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when(item.itemId){
            R.id.menu_prev ->{
                val prevScheduleFragment = PrevScheduleFragment()
                openFragment(prevScheduleFragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.menu_next->{
                val nextScheduleFragment = NextScheduleFragment()
                openFragment(nextScheduleFragment)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    private fun openFragment(fragment: Fragment){
        val transation = supportFragmentManager.beginTransaction()
        transation.replace(R.id.container, fragment)
        transation.addToBackStack(null)
        transation.commit()
    }

}
