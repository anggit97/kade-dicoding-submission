package com.anggitprayogo.footballclub_scheduling.screen.prev_schedule_fragment.view

import com.anggitprayogo.footballclub_scheduling.screen.prev_schedule_fragment.model.DataEvent

interface PrevScheduleView {

    fun onProgress()
    fun showError(error: String?)
    fun showResponse(response: String?)
    fun postProgress()
    fun isEmpty()
    fun showData(datas: MutableList<DataEvent>?)

}