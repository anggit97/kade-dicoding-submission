package com.anggitprayogo.footballapp.fotballapp.feature.mainactivity

class MainActivityPresenter {
}