package com.anggitprayogo.footballapp.fotballapp.feature.favourites

class FavouritePresenter {
}