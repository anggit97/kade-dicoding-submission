package com.anggitprayogo.footballapp.fotballapp.feature.favourites

interface FavouriteView {
}