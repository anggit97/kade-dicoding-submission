package com.anggitprayogo.footballapp.fotballapp.feature.mainactivity

interface MainActivityView {
}