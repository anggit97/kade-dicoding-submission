package com.anggitprayogo.footballapp.fotballapp.config

class Config {

    companion object {
        val LEAGUE_ID: String = "LEAGUE_ID"
        val DATABASE_NAME: String = "FootballApp.db"
    }

}